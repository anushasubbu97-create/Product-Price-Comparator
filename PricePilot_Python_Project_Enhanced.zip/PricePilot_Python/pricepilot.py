"""PricePilot - colourful product price comparison desktop application.
Built with Python + CustomTkinter. No HTML or CSS.
"""
import customtkinter as ctk
from tkinter import ttk, filedialog, messagebox
from datetime import date, datetime
import json, csv, os

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(APP_DIR, 'pricepilot_data.json')
WATCH_FILE = os.path.join(APP_DIR, 'pricepilot_watchlist.json')
CATEGORIES = ['Electronics', 'Grocery', 'Home & Kitchen', 'Fashion', 'Personal Care', 'Books', 'Other']
P = {
    'navy':'#182449', 'navy2':'#263665', 'blue':'#3978F6', 'purple':'#8056E8',
    'cyan':'#13B8C8', 'pink':'#EF6AA8', 'green':'#13A879', 'orange':'#F2A640',
    'red':'#E45B69', 'bg':'#F4F6FC', 'card':'#FFFFFF', 'text':'#202B45',
    'muted':'#7C879F', 'line':'#E6EAF3', 'softblue':'#EDF3FF', 'softgreen':'#E9F8F2',
    'softpurple':'#F2EDFF', 'softorange':'#FFF5E6', 'softpink':'#FFF0F6'
}
SAMPLE = [
 {'name':'Wireless Earbuds','category':'Electronics','store':'TechHub','price':1499,'date':'2026-11-24','notes':'Bluetooth earbuds, 20-hour battery'},
 {'name':'Wireless Earbuds','category':'Electronics','store':'MegaMart','price':1299,'date':'2026-11-24','notes':'Limited-time offer'},
 {'name':'Wireless Earbuds','category':'Electronics','store':'ClickCart','price':1599,'date':'2026-11-23','notes':''},
 {'name':'Rice 5 kg','category':'Grocery','store':'Daily Needs','price':345,'date':'2026-11-24','notes':'Premium basmati'},
 {'name':'Rice 5 kg','category':'Grocery','store':'Fresh Basket','price':329,'date':'2026-11-23','notes':''},
 {'name':'Rice 5 kg','category':'Grocery','store':'MegaMart','price':359,'date':'2026-11-22','notes':''},
 {'name':'Mixer Grinder','category':'Home & Kitchen','store':'HomeSquare','price':2499,'date':'2026-11-24','notes':'750W motor'},
 {'name':'Mixer Grinder','category':'Home & Kitchen','store':'MegaMart','price':2299,'date':'2026-11-23','notes':'3 jars included'},
 {'name':'Mixer Grinder','category':'Home & Kitchen','store':'ClickCart','price':2599,'date':'2026-11-22','notes':''},
 {'name':'Cotton T-Shirt','category':'Fashion','store':'Style Street','price':499,'date':'2026-11-24','notes':'100% cotton'},
 {'name':'Cotton T-Shirt','category':'Fashion','store':'MegaMart','price':449,'date':'2026-11-23','notes':''},
 {'name':'Cotton T-Shirt','category':'Fashion','store':'TrendBox','price':529,'date':'2026-11-22','notes':''},
 {'name':'Face Wash 150ml','category':'Personal Care','store':'Glow Store','price':189,'date':'2026-11-24','notes':''},
 {'name':'Face Wash 150ml','category':'Personal Care','store':'Daily Needs','price':175,'date':'2026-11-23','notes':''},
 {'name':'Face Wash 150ml','category':'Personal Care','store':'ClickCart','price':199,'date':'2026-11-22','notes':''},
 {'name':'Python Basics','category':'Books','store':'Book Corner','price':399,'date':'2026-11-24','notes':'Paperback edition'},
 {'name':'Python Basics','category':'Books','store':'ReadMore','price':349,'date':'2026-11-23','notes':''},
 {'name':'Python Basics','category':'Books','store':'MegaMart','price':429,'date':'2026-11-22','notes':''},
 {'name':'Bluetooth Speaker','category':'Electronics','store':'TechHub','price':1899,'date':'2026-11-21','notes':'Portable speaker'},
 {'name':'Bluetooth Speaker','category':'Electronics','store':'ClickCart','price':1749,'date':'2026-11-21','notes':''},
 {'name':'Bluetooth Speaker','category':'Electronics','store':'MegaMart','price':1999,'date':'2026-11-20','notes':''},
 {'name':'Cooking Oil 1L','category':'Grocery','store':'Fresh Basket','price':155,'date':'2026-11-21','notes':'Sunflower oil'},
 {'name':'Cooking Oil 1L','category':'Grocery','store':'Daily Needs','price':149,'date':'2026-11-20','notes':''},
 {'name':'Cooking Oil 1L','category':'Grocery','store':'MegaMart','price':162,'date':'2026-11-19','notes':''},
 {'name':'Desk Lamp','category':'Home & Kitchen','store':'HomeSquare','price':799,'date':'2026-11-21','notes':'LED lamp'},
 {'name':'Desk Lamp','category':'Home & Kitchen','store':'ClickCart','price':699,'date':'2026-11-20','notes':''},
 {'name':'Desk Lamp','category':'Home & Kitchen','store':'MegaMart','price':849,'date':'2026-11-19','notes':''},
 {'name':'Backpack','category':'Fashion','store':'TrendBox','price':1199,'date':'2026-11-20','notes':'Water-resistant'},
 {'name':'Backpack','category':'Fashion','store':'Style Street','price':1099,'date':'2026-11-19','notes':''},
 {'name':'Backpack','category':'Fashion','store':'MegaMart','price':1299,'date':'2026-11-18','notes':''},
 {'name':'Sunscreen SPF 50','category':'Personal Care','store':'Glow Store','price':349,'date':'2026-11-20','notes':'50ml'},
 {'name':'Sunscreen SPF 50','category':'Personal Care','store':'Daily Needs','price':319,'date':'2026-11-19','notes':''},
 {'name':'Sunscreen SPF 50','category':'Personal Care','store':'ClickCart','price':379,'date':'2026-11-18','notes':''},
 {'name':'Notebook Set','category':'Books','store':'Book Corner','price':180,'date':'2026-11-19','notes':'Pack of 3'},
 {'name':'Notebook Set','category':'Books','store':'ReadMore','price':165,'date':'2026-11-18','notes':''},
 {'name':'Notebook Set','category':'Books','store':'MegaMart','price':195,'date':'2026-11-17','notes':''},
]

ctk.set_appearance_mode('light')
ctk.set_default_color_theme('blue')

class PricePilot(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title('PricePilot | Smart Price Comparator')
        self.geometry('1320x850')
        self.minsize(1080,720)
        self.configure(fg_color=P['bg'])
        self.records = self.load_records()
        self.watchlist = self.load_watchlist()
        self.active = 'Overview'
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.build_shell()
        self.show_page('Overview')

    def load_records(self):
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, encoding='utf-8') as f:
                    data = json.load(f)
                if isinstance(data, list): return data
            except Exception: pass
        return [dict(r, id=str(i)) for i, r in enumerate(SAMPLE)]

    def load_watchlist(self):
        if os.path.exists(WATCH_FILE):
            try:
                with open(WATCH_FILE, encoding='utf-8') as f: return json.load(f)
            except Exception: pass
        return []

    def save_records(self):
        with open(DATA_FILE, 'w', encoding='utf-8') as f: json.dump(self.records, f, indent=2, ensure_ascii=False)

    def save_watchlist(self):
        with open(WATCH_FILE, 'w', encoding='utf-8') as f: json.dump(self.watchlist, f, indent=2, ensure_ascii=False)

    def money(self, amount): return '₹{:,.2f}'.format(float(amount)).rstrip('0').rstrip('.')
    def groups(self):
        result = {}
        for record in self.records: result.setdefault(record['name'], []).append(record)
        return result
    def cheapest(self, rows): return min(rows, key=lambda r: float(r['price']))

    def build_shell(self):
        self.sidebar = ctk.CTkFrame(self, width=238, corner_radius=0, fg_color=P['navy'])
        self.sidebar.grid(row=0, column=0, sticky='nsew')
        self.sidebar.grid_propagate(False)
        ctk.CTkLabel(self.sidebar, text='✦ PricePilot', font=ctk.CTkFont(size=29, weight='bold'), text_color='white').pack(anchor='w', padx=22, pady=(30, 3))
        ctk.CTkLabel(self.sidebar, text='SMART SHOPPING, BETTER SAVINGS', font=ctk.CTkFont(size=10, weight='bold'), text_color='#AAB8F5').pack(anchor='w', padx=24, pady=(0, 30))
        self.nav_buttons = {}
        nav_items = [('Overview','⌂'), ('Compare Prices','⇄'), ('Price Records','▤'), ('Price Watch','♡'), ('Insights','✧')]
        for name, icon in nav_items:
            btn = ctk.CTkButton(self.sidebar, text=f'{icon}   {name}', anchor='w', height=48, corner_radius=12,
                fg_color=P['navy2'] if name == 'Overview' else 'transparent', hover_color='#35477D', text_color='white',
                font=ctk.CTkFont(size=14, weight='bold'), command=lambda n=name: self.show_page(n))
            btn.pack(fill='x', padx=14, pady=5)
            self.nav_buttons[name] = btn
        ctk.CTkFrame(self.sidebar, height=1, fg_color='#394875').pack(fill='x', padx=18, pady=(24, 16))
        ctk.CTkLabel(self.sidebar, text='YOUR SMART SHOPPING SPACE', text_color='#AAB8F5', font=ctk.CTkFont(size=10, weight='bold')).pack(anchor='w', padx=22)
        ctk.CTkLabel(self.sidebar, text='Compare • Discover • Save', text_color='#D8DFFF', font=ctk.CTkFont(size=12)).pack(anchor='w', padx=22, pady=(5, 0))
        ctk.CTkLabel(self.sidebar, text='✦  Make every rupee count', text_color='#AAB8F5', font=ctk.CTkFont(size=11)).pack(side='bottom', pady=24)

        self.main = ctk.CTkFrame(self, fg_color='transparent')
        self.main.grid(row=0, column=1, sticky='nsew', padx=28, pady=22)
        self.main.grid_columnconfigure(0, weight=1)
        self.main.grid_rowconfigure(1, weight=1)
        self.header = ctk.CTkFrame(self.main, fg_color='transparent')
        self.header.grid(row=0, column=0, sticky='ew', pady=(0, 15))
        self.header.grid_columnconfigure(0, weight=1)
        self.page_title = ctk.CTkLabel(self.header, text='', font=ctk.CTkFont(size=28, weight='bold'), text_color=P['text'])
        self.page_title.grid(row=0, column=0, sticky='w')
        ctk.CTkLabel(self.header, text='A smarter way to shop ✨', text_color=P['muted'], font=ctk.CTkFont(size=12)).grid(row=1, column=0, sticky='w', pady=(2, 0))
        ctk.CTkButton(self.header, text='＋  Add Price', height=42, corner_radius=12, fg_color=P['purple'], hover_color='#6941C6',
            font=ctk.CTkFont(size=13, weight='bold'), command=self.add_dialog).grid(row=0, column=1, rowspan=2, sticky='e')
        self.content = ctk.CTkScrollableFrame(self.main, fg_color='transparent', corner_radius=0)
        self.content.grid(row=1, column=0, sticky='nsew')
        self.content.grid_columnconfigure((0,1), weight=1)

    def clear(self):
        for widget in self.content.winfo_children(): widget.destroy()

    def show_page(self, name):
        self.active = name
        titles = {'Overview':'Good shopping starts here ✨', 'Compare Prices':'Find your best deal ⇄', 'Price Records':'Your price collection 🛍️', 'Price Watch':'Your price watchlist ♡', 'Insights':'Your shopping insights 📊'}
        self.page_title.configure(text=titles[name])
        for nav, btn in self.nav_buttons.items(): btn.configure(fg_color=P['navy2'] if nav == name else 'transparent')
        self.clear()
        if name == 'Overview': self.dashboard()
        elif name == 'Compare Prices': self.compare_page()
        elif name == 'Price Records': self.records_page()
        elif name == 'Price Watch': self.watch_page()
        else: self.insights_page()

    def card(self, parent, title, value, accent, sub, emoji='✦'):
        box = ctk.CTkFrame(parent, fg_color=P['card'], corner_radius=18, border_width=1, border_color=P['line'])
        top = ctk.CTkFrame(box, fg_color='transparent'); top.pack(fill='x', padx=16, pady=(13, 0))
        ctk.CTkLabel(top, text=emoji, font=ctk.CTkFont(size=20), text_color=accent).pack(side='left')
        ctk.CTkLabel(top, text=title, font=ctk.CTkFont(size=11, weight='bold'), text_color=P['muted']).pack(side='left', padx=8)
        ctk.CTkLabel(box, text=value, font=ctk.CTkFont(size=25, weight='bold'), text_color=accent).pack(anchor='w', padx=17, pady=(6, 0))
        ctk.CTkLabel(box, text=sub, font=ctk.CTkFont(size=10), text_color=P['muted']).pack(anchor='w', padx=17, pady=(1, 13))
        return box

    def panel(self, parent, title, row, col, colspan=1):
        frame = ctk.CTkFrame(parent, fg_color='white', corner_radius=17, border_width=1, border_color=P['line'])
        frame.grid(row=row, column=col, columnspan=colspan, sticky='nsew', padx=7, pady=9)
        ctk.CTkLabel(frame, text=title, font=ctk.CTkFont(size=16, weight='bold'), text_color=P['text']).pack(anchor='w', padx=16, pady=(14, 10))
        return frame

    def dashboard(self):
        total = len(self.records)
        stores = len({r['store'].lower() for r in self.records})
        products = len(self.groups())
        avg = sum(float(r['price']) for r in self.records) / total if total else 0
        gaps = [max(float(x['price']) for x in rows)-min(float(x['price']) for x in rows) for rows in self.groups().values() if rows]
        potential = sum(gaps)
        stats = ctk.CTkFrame(self.content, fg_color='transparent'); stats.grid(row=0, column=0, columnspan=2, sticky='ew')
        stats.grid_columnconfigure((0,1,2,3), weight=1)
        cards = [('PRODUCTS', str(products), P['purple'], 'Different products', '▣'), ('PRICE ENTRIES', str(total), P['blue'], 'Saved price offers', '▤'), ('STORES', str(stores), P['cyan'], 'Stores compared', '⌖'), ('PRICE GAP', self.money(potential), P['green'], 'Possible savings gap', '↗')]
        for i, args in enumerate(cards): self.card(stats, *args).grid(row=0, column=i, sticky='ew', padx=(0 if i == 0 else 7, 7), pady=5)

        hero = ctk.CTkFrame(self.content, fg_color='#263D79', corner_radius=20)
        hero.grid(row=1, column=0, columnspan=2, sticky='ew', padx=7, pady=(14, 8))
        hero.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(hero, text='SHOP SMARTER. SAVE MORE.', text_color='#BFD0FF', font=ctk.CTkFont(size=11, weight='bold')).grid(row=0, column=0, sticky='w', padx=22, pady=(18, 4))
        ctk.CTkLabel(hero, text='Your next great deal is just a comparison away.', text_color='white', font=ctk.CTkFont(size=21, weight='bold')).grid(row=1, column=0, sticky='w', padx=22)
        ctk.CTkLabel(hero, text='Compare store prices, track target prices and make confident shopping choices.', text_color='#D9E2FF', font=ctk.CTkFont(size=12)).grid(row=2, column=0, sticky='w', padx=22, pady=(4, 16))
        ctk.CTkButton(hero, text='Compare prices  →', fg_color='#F3B64D', hover_color='#D99A2B', text_color='#26304D', height=38, font=ctk.CTkFont(size=12, weight='bold'), command=lambda:self.show_page('Compare Prices')).grid(row=0, column=1, rowspan=3, padx=24)

        best_panel = self.panel(self.content, '🏆  Best deals in your records', 2, 0)
        best = sorted(self.groups().items(), key=lambda item: float(self.cheapest(item[1])['price']))[:6]
        if not best: ctk.CTkLabel(best_panel, text='Add price records to discover deals.', text_color=P['muted']).pack(anchor='w', padx=16, pady=10)
        for name, rows in best:
            low = self.cheapest(rows)
            line = ctk.CTkFrame(best_panel, fg_color='#F7F9FE', corner_radius=10); line.pack(fill='x', padx=12, pady=4)
            ctk.CTkLabel(line, text='✦', text_color=P['orange'], font=ctk.CTkFont(size=17)).pack(side='left', padx=10, pady=8)
            ctk.CTkLabel(line, text=f"{name}\n{low['store']}", justify='left', text_color=P['text'], font=ctk.CTkFont(size=11, weight='bold')).pack(side='left', padx=3, pady=5)
            ctk.CTkLabel(line, text=self.money(low['price']), text_color=P['green'], font=ctk.CTkFont(size=14, weight='bold')).pack(side='right', padx=12)

        watch_panel = self.panel(self.content, '♡  Price watch alerts', 2, 1)
        alerts = self.watch_statuses()
        if not alerts: ctk.CTkLabel(watch_panel, text='No products being watched yet.\nAdd a target price in Price Watch.', justify='left', text_color=P['muted']).pack(anchor='w', padx=16, pady=10)
        for item, status, current in alerts[:5]:
            line = ctk.CTkFrame(watch_panel, fg_color=P['softgreen'] if status == 'Target reached!' else '#F7F9FE', corner_radius=10); line.pack(fill='x', padx=12, pady=4)
            ctk.CTkLabel(line, text='●' if status == 'Target reached!' else '○', text_color=P['green'] if status == 'Target reached!' else P['orange']).pack(side='left', padx=10, pady=10)
            ctk.CTkLabel(line, text=item['name'], text_color=P['text'], font=ctk.CTkFont(size=11, weight='bold')).pack(side='left')
            ctk.CTkLabel(line, text=status, text_color=P['green'] if status == 'Target reached!' else P['muted'], font=ctk.CTkFont(size=10, weight='bold')).pack(side='right', padx=10)

        tip = ctk.CTkFrame(self.content, fg_color=P['softorange'], corner_radius=14)
        tip.grid(row=3, column=0, columnspan=2, sticky='ew', padx=7, pady=8)
        ctk.CTkLabel(tip, text='💡 SMART SHOPPING TIP', text_color='#A56A11', font=ctk.CTkFont(size=11, weight='bold')).pack(anchor='w', padx=15, pady=(10, 2))
        ctk.CTkLabel(tip, text='Always compare the final price and product details before buying. The lowest listed price may not include delivery charges.', text_color='#785A2C', font=ctk.CTkFont(size=11), wraplength=850, justify='left').pack(anchor='w', padx=15, pady=(0, 11))

    def compare_page(self):
        names = sorted(self.groups())
        if not names:
            ctk.CTkLabel(self.content, text='No products yet. Add price records first.', text_color=P['muted']).grid(row=0, column=0, padx=20, pady=30)
            return
        control = ctk.CTkFrame(self.content, fg_color='white', corner_radius=16, border_width=1, border_color=P['line'])
        control.grid(row=0, column=0, columnspan=2, sticky='ew', padx=7, pady=8)
        ctk.CTkLabel(control, text='Choose a product to compare', font=ctk.CTkFont(size=14, weight='bold'), text_color=P['text']).pack(side='left', padx=16, pady=16)
        self.compare_choice = ctk.CTkComboBox(control, values=names, width=280, height=38, command=lambda _=None:self.render_comparison())
        self.compare_choice.pack(side='left', padx=10, pady=12); self.compare_choice.set(names[0])
        self.compare_area = ctk.CTkFrame(self.content, fg_color='transparent')
        self.compare_area.grid(row=1, column=0, columnspan=2, sticky='ew')
        self.compare_area.grid_columnconfigure((0,1,2), weight=1)
        self.render_comparison()

    def render_comparison(self):
        if not hasattr(self, 'compare_area') or not self.compare_area.winfo_exists(): return
        for w in self.compare_area.winfo_children(): w.destroy()
        name = self.compare_choice.get()
        rows = sorted(self.groups().get(name, []), key=lambda r: float(r['price']))
        if not rows: return
        low = float(rows[0]['price']); high = float(rows[-1]['price']); saving = high-low
        summary = ctk.CTkFrame(self.compare_area, fg_color='#263D79', corner_radius=18)
        summary.grid(row=0, column=0, columnspan=3, sticky='ew', padx=7, pady=8)
        ctk.CTkLabel(summary, text='BEST AVAILABLE PRICE', text_color='#C9D5FF', font=ctk.CTkFont(size=11, weight='bold')).pack(pady=(14, 2))
        ctk.CTkLabel(summary, text=self.money(low), text_color='white', font=ctk.CTkFont(size=31, weight='bold')).pack()
        ctk.CTkLabel(summary, text=f"at {rows[0]['store']}  •  Save up to {self.money(saving)} compared with the highest listed price", text_color='#D9E2FF', font=ctk.CTkFont(size=12)).pack(pady=(2, 15))
        colors = [P['softgreen'], P['softblue'], P['softpurple'], P['softorange'], P['softpink']]
        for i, record in enumerate(rows):
            is_best = i == 0
            box = ctk.CTkFrame(self.compare_area, fg_color=colors[i % len(colors)], corner_radius=16, border_width=2 if is_best else 0, border_color=P['green'] if is_best else colors[i % len(colors)])
            box.grid(row=1+i//3, column=i%3, sticky='ew', padx=7, pady=7)
            ctk.CTkLabel(box, text='🏆 BEST PRICE' if is_best else f'OPTION {i+1}', text_color=P['green'] if is_best else P['muted'], font=ctk.CTkFont(size=10, weight='bold')).pack(anchor='w', padx=14, pady=(13, 5))
            ctk.CTkLabel(box, text=record['store'], text_color=P['text'], font=ctk.CTkFont(size=15, weight='bold')).pack(anchor='w', padx=14)
            ctk.CTkLabel(box, text=self.money(record['price']), text_color=P['green'] if is_best else P['blue'], font=ctk.CTkFont(size=23, weight='bold')).pack(anchor='w', padx=14, pady=(4, 0))
            ctk.CTkLabel(box, text=f"Added: {record.get('date','—')}", text_color=P['muted'], font=ctk.CTkFont(size=10)).pack(anchor='w', padx=14, pady=(2, 12))

    def records_page(self):
        tools = ctk.CTkFrame(self.content, fg_color='white', corner_radius=14, border_width=1, border_color=P['line'])
        tools.grid(row=0, column=0, columnspan=2, sticky='ew', padx=7, pady=(0, 12)); tools.grid_columnconfigure(0, weight=1)
        self.search = ctk.CTkEntry(tools, placeholder_text='⌕  Search product, store, category or notes...', height=40)
        self.search.grid(row=0, column=0, sticky='ew', padx=12, pady=12); self.search.bind('<KeyRelease>', lambda e:self.fill_table())
        self.category_filter = ctk.CTkComboBox(tools, values=['All categories']+CATEGORIES, width=175, command=lambda _=None:self.fill_table())
        self.category_filter.set('All categories'); self.category_filter.grid(row=0, column=1, padx=5)
        ctk.CTkButton(tools, text='Import CSV', width=105, command=self.import_csv).grid(row=0, column=2, padx=5)
        ctk.CTkButton(tools, text='Export CSV', width=105, fg_color=P['green'], hover_color='#0D8B63', command=self.export_csv).grid(row=0, column=3, padx=12)
        wrap = ctk.CTkFrame(self.content, fg_color='white', corner_radius=14, border_width=1, border_color=P['line'])
        wrap.grid(row=1, column=0, columnspan=2, sticky='nsew', padx=7); wrap.grid_columnconfigure(0, weight=1); wrap.grid_rowconfigure(0, weight=1)
        style = ttk.Style(); style.theme_use('clam'); style.configure('Treeview', rowheight=35, font=('Arial',10), background='white', fieldbackground='white', foreground=P['text'])
        style.configure('Treeview.Heading', font=('Arial',10,'bold'), background='#E9EDFF', foreground=P['navy'])
        style.map('Treeview', background=[('selected','#DCE7FF')], foreground=[('selected',P['navy'])])
        self.tree = ttk.Treeview(wrap, columns=('product','category','store','price','date'), show='headings', height=17)
        for col, label, width in [('product','Product',220),('category','Category',155),('store','Store',150),('price','Price (₹)',110),('date','Date',115)]:
            self.tree.heading(col, text=label); self.tree.column(col, width=width, anchor='w')
        self.tree.grid(row=0, column=0, sticky='nsew', padx=10, pady=10)
        scroll = ttk.Scrollbar(wrap, orient='vertical', command=self.tree.yview); self.tree.configure(yscrollcommand=scroll.set); scroll.grid(row=0, column=1, sticky='ns', pady=10)
        actions = ctk.CTkFrame(self.content, fg_color='transparent'); actions.grid(row=2, column=0, columnspan=2, sticky='ew', padx=7, pady=10)
        ctk.CTkButton(actions, text='＋ Add record', fg_color=P['purple'], command=self.add_dialog).pack(side='left', padx=(0,8))
        ctk.CTkButton(actions, text='Delete selected', fg_color=P['red'], hover_color='#C33E4D', command=self.delete_record).pack(side='left')
        self.fill_table()

    def fill_table(self):
        if not hasattr(self, 'tree') or not self.tree.winfo_exists(): return
        for item in self.tree.get_children(): self.tree.delete(item)
        query = self.search.get().lower() if hasattr(self, 'search') else ''
        category = self.category_filter.get() if hasattr(self, 'category_filter') else 'All categories'
        for i, r in enumerate(self.records):
            if category != 'All categories' and r.get('category') != category: continue
            searchable = ' '.join(str(r.get(k,'')) for k in ('name','category','store','notes')).lower()
            if query and query not in searchable: continue
            self.tree.insert('', 'end', iid=str(i), values=(r['name'],r['category'],r['store'],self.money(r['price']),r.get('date','')))

    def delete_record(self):
        selected = self.tree.selection()
        if not selected: messagebox.showinfo('Select a record','Please select a row first.'); return
        if messagebox.askyesno('Delete record','Are you sure you want to delete the selected price record?'):
            self.records.pop(int(selected[0])); self.save_records(); self.show_page('Price Records')

    def watch_statuses(self):
        result = []
        groups = self.groups()
        for item in self.watchlist:
            prices = groups.get(item['name'], [])
            current = self.cheapest(prices)['price'] if prices else None
            status = 'No price yet' if current is None else ('Target reached!' if float(current) <= float(item['target']) else 'Watching price')
            result.append((item, status, current))
        return result

    def watch_page(self):
        intro = ctk.CTkFrame(self.content, fg_color=P['softpurple'], corner_radius=16)
        intro.grid(row=0, column=0, columnspan=2, sticky='ew', padx=7, pady=8)
        ctk.CTkLabel(intro, text='♡  Set a target price and let PricePilot check your saved offers.', text_color='#593D9E', font=ctk.CTkFont(size=14, weight='bold')).pack(anchor='w', padx=17, pady=15)
        ctk.CTkButton(self.content, text='＋ Add product to watchlist', fg_color=P['purple'], height=40, command=self.watch_dialog).grid(row=1, column=0, sticky='w', padx=8, pady=8)
        panel = self.panel(self.content, 'Your watched products', 2, 0, 2)
        if not self.watchlist:
            ctk.CTkLabel(panel, text='Your watchlist is empty. Add a product and your target price to get started.', text_color=P['muted']).pack(anchor='w', padx=16, pady=15)
        for item, status, current in self.watch_statuses():
            line = ctk.CTkFrame(panel, fg_color=P['softgreen'] if status == 'Target reached!' else '#F7F9FE', corner_radius=12)
            line.pack(fill='x', padx=12, pady=5)
            info = ctk.CTkFrame(line, fg_color='transparent'); info.pack(side='left', fill='x', expand=True, padx=12, pady=9)
            ctk.CTkLabel(info, text=item['name'], text_color=P['text'], font=ctk.CTkFont(size=13, weight='bold')).pack(anchor='w')
            current_text = self.money(current) if current is not None else 'No saved offer'
            ctk.CTkLabel(info, text=f"Target: {self.money(item['target'])}   •   Best saved price: {current_text}", text_color=P['muted'], font=ctk.CTkFont(size=11)).pack(anchor='w', pady=(2,0))
            ctk.CTkLabel(line, text=status, text_color=P['green'] if status == 'Target reached!' else P['orange'], font=ctk.CTkFont(size=11, weight='bold')).pack(side='left', padx=12)
            ctk.CTkButton(line, text='Remove', width=72, height=30, fg_color=P['red'], hover_color='#C33E4D', command=lambda x=item:self.remove_watch(x)).pack(side='right', padx=10)

    def watch_dialog(self):
        win = ctk.CTkToplevel(self); win.title('Add price watch'); win.geometry('430x330'); win.resizable(False,False); win.configure(fg_color=P['bg']); win.transient(self); win.grab_set()
        ctk.CTkLabel(win, text='Create a price watch ♡', font=ctk.CTkFont(size=23, weight='bold'), text_color=P['navy']).pack(pady=(22,5))
        ctk.CTkLabel(win, text='We will compare your target with saved prices.', text_color=P['muted']).pack(pady=(0,15))
        ctk.CTkLabel(win, text='PRODUCT NAME', text_color=P['text'], font=ctk.CTkFont(size=11, weight='bold')).pack(anchor='w', padx=28)
        name = ctk.CTkComboBox(win, values=sorted(self.groups()) or ['Add records first'], width=370, height=38); name.pack(pady=(4,12));
        if self.groups(): name.set(sorted(self.groups())[0])
        ctk.CTkLabel(win, text='TARGET PRICE (₹)', text_color=P['text'], font=ctk.CTkFont(size=11, weight='bold')).pack(anchor='w', padx=28)
        target = ctk.CTkEntry(win, width=370, height=38, placeholder_text='Example: 1200'); target.pack(pady=(4,10))
        def save_watch():
            product = name.get().strip()
            try: value = float(target.get().strip())
            except ValueError: value = 0
            if not product or product == 'Add records first' or value <= 0:
                messagebox.showerror('Check details','Choose a product and enter a valid target price.', parent=win); return
            self.watchlist = [x for x in self.watchlist if x['name'].lower() != product.lower()]
            self.watchlist.append({'name':product, 'target':value}); self.save_watchlist(); win.destroy(); self.show_page('Price Watch')
        ctk.CTkButton(win, text='Save price watch', height=42, fg_color=P['purple'], command=save_watch).pack(fill='x', padx=28, pady=15)

    def remove_watch(self, item):
        self.watchlist = [x for x in self.watchlist if x != item]; self.save_watchlist(); self.show_page('Price Watch')

    def insights_page(self):
        groups = self.groups(); total = len(self.records)
        avg = sum(float(r['price']) for r in self.records)/total if total else 0
        store_count = len({r['store'].lower() for r in self.records})
        stats = ctk.CTkFrame(self.content, fg_color='transparent'); stats.grid(row=0, column=0, columnspan=2, sticky='ew'); stats.grid_columnconfigure((0,1,2), weight=1)
        for i, args in enumerate([('UNIQUE PRODUCTS',str(len(groups)),P['purple'],'Products tracked','▣'),('AVERAGE PRICE',self.money(avg),P['blue'],'Across all offers','₹'),('TOTAL STORES',str(store_count),P['green'],'Stores in your records','⌖')]):
            self.card(stats,*args).grid(row=0, column=i, sticky='ew', padx=7, pady=6)
        panel = self.panel(self.content, '📊  Average price by category', 1, 0, 2)
        categories = {}
        for r in self.records: categories.setdefault(r['category'], []).append(float(r['price']))
        colors = [P['blue'],P['purple'],P['cyan'],P['pink'],P['orange'],P['green']]
        max_avg = max([sum(v)/len(v) for v in categories.values()] or [1])
        for i, (cat, values) in enumerate(sorted(categories.items())):
            mean = sum(values)/len(values)
            row = ctk.CTkFrame(panel, fg_color='#F8FAFF', corner_radius=10); row.pack(fill='x', padx=12, pady=4)
            ctk.CTkLabel(row, text=cat, width=155, anchor='w', font=ctk.CTkFont(size=12, weight='bold'), text_color=P['text']).pack(side='left', padx=10, pady=10)
            bar = ctk.CTkProgressBar(row, progress_color=colors[i%len(colors)], fg_color='#E8ECF5', height=12); bar.pack(side='left', fill='x', expand=True, padx=8); bar.set(mean/max_avg if max_avg else 0)
            ctk.CTkLabel(row, text=self.money(mean), width=95, text_color=P['blue'], font=ctk.CTkFont(size=12, weight='bold')).pack(side='right', padx=10)
        insight = self.panel(self.content, '🏅  Biggest price difference', 2, 0)
        gaps = [(name, max(float(r['price']) for r in rows)-min(float(r['price']) for r in rows)) for name, rows in groups.items() if len(rows)>1]
        if gaps:
            name, gap = max(gaps, key=lambda x:x[1])
            ctk.CTkLabel(insight, text=name, text_color=P['text'], font=ctk.CTkFont(size=15, weight='bold')).pack(anchor='w', padx=16)
            ctk.CTkLabel(insight, text=f'Price difference: {self.money(gap)}', text_color=P['green'], font=ctk.CTkFont(size=18, weight='bold')).pack(anchor='w', padx=16, pady=(3,13))
        else: ctk.CTkLabel(insight, text='Add more store offers for the same product to compare price differences.', text_color=P['muted'], wraplength=380).pack(anchor='w', padx=16, pady=10)
        export = self.panel(self.content, '📁  Reports', 2, 1)
        ctk.CTkLabel(export, text='Create a simple text report with the best saved offer for every product.', text_color=P['muted'], wraplength=360, justify='left').pack(anchor='w', padx=16)
        ctk.CTkButton(export, text='Download summary (TXT)', fg_color=P['purple'], command=self.export_summary).pack(anchor='w', padx=16, pady=12)

    def add_dialog(self):
        win = ctk.CTkToplevel(self); win.title('Add a price'); win.geometry('470x650'); win.resizable(False,False); win.configure(fg_color=P['bg']); win.transient(self); win.grab_set()
        ctk.CTkLabel(win, text='Add a new price ✨', font=ctk.CTkFont(size=24, weight='bold'), text_color=P['navy']).pack(pady=(20,4))
        ctk.CTkLabel(win, text='Enter product and store details below', text_color=P['muted']).pack(pady=(0,12))
        fields = {}
        def entry(label, key, placeholder=''):
            ctk.CTkLabel(win, text=label, font=ctk.CTkFont(size=11, weight='bold'), text_color=P['text']).pack(anchor='w', padx=34, pady=(7,3))
            field = ctk.CTkEntry(win, width=395, height=37, placeholder_text=placeholder); field.pack(padx=30); fields[key] = field
        entry('PRODUCT NAME','name','e.g. Wireless Earbuds')
        ctk.CTkLabel(win, text='CATEGORY', font=ctk.CTkFont(size=11, weight='bold'), text_color=P['text']).pack(anchor='w', padx=34, pady=(7,3))
        category = ctk.CTkComboBox(win, values=CATEGORIES, width=395, height=37); category.pack(); category.set(CATEGORIES[0])
        entry('STORE NAME','store','e.g. MegaMart'); entry('PRICE (₹)','price','e.g. 1299')
        entry('DATE (YYYY-MM-DD)','date',date.today().isoformat()); fields['date'].insert(0,date.today().isoformat())
        entry('NOTES (OPTIONAL)','notes','Offer, size or product details')
        def save_record():
            name = fields['name'].get().strip(); store = fields['store'].get().strip(); raw = fields['price'].get().strip(); dt = fields['date'].get().strip()
            try: price = float(raw)
            except ValueError: price = 0
            try: datetime.strptime(dt, '%Y-%m-%d'); valid_date = True
            except ValueError: valid_date = False
            if not name or not store or price <= 0 or price > 10000000 or not valid_date:
                messagebox.showerror('Check your details','Enter a product, store, positive price and valid date (YYYY-MM-DD).', parent=win); return
            self.records.insert(0, {'id':str(datetime.now().timestamp()), 'name':name, 'category':category.get(), 'store':store, 'price':price, 'date':dt, 'notes':fields['notes'].get().strip()})
            self.save_records(); win.destroy(); self.show_page('Price Records')
        ctk.CTkButton(win, text='Save price record', height=43, fg_color=P['purple'], hover_color='#6941C6', font=ctk.CTkFont(size=14, weight='bold'), command=save_record).pack(fill='x', padx=30, pady=19)

    def import_csv(self):
        path = filedialog.askopenfilename(filetypes=[('CSV files','*.csv')])
        if not path: return
        try:
            with open(path, newline='', encoding='utf-8-sig') as f: rows = list(csv.DictReader(f))
            required = {'name','category','store','price','date'}
            if not rows or not required.issubset(rows[0]): raise ValueError('CSV must contain: name, category, store, price, date')
            new = []
            for row in rows:
                price = float(row['price'])
                if not row['name'].strip() or not row['store'].strip() or price <= 0: raise ValueError('A row contains missing details or an invalid price.')
                new.append({'id':str(datetime.now().timestamp())+str(len(new)), 'name':row['name'].strip(), 'category':row['category'].strip(), 'store':row['store'].strip(), 'price':price, 'date':row['date'].strip(), 'notes':row.get('notes','')})
            self.records = new + self.records; self.save_records(); self.show_page('Price Records')
            messagebox.showinfo('Import complete', f'{len(new)} records imported successfully.')
        except Exception as error: messagebox.showerror('Import failed', str(error))

    def export_csv(self):
        path = filedialog.asksaveasfilename(defaultextension='.csv', initialfile='pricepilot-records.csv', filetypes=[('CSV files','*.csv')])
        if not path: return
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['name','category','store','price','date','notes']); writer.writeheader(); writer.writerows(self.records)
        messagebox.showinfo('Export complete','Your CSV file has been saved.')

    def export_summary(self):
        path = filedialog.asksaveasfilename(defaultextension='.txt', initialfile='pricepilot-summary.txt', filetypes=[('Text files','*.txt')])
        if not path: return
        lines = ['PRICEPILOT - SMART PRICE COMPARISON SUMMARY', f'Total records: {len(self.records)}', f'Unique products: {len(self.groups())}', '', 'BEST PRICE BY PRODUCT']
        for name, rows in sorted(self.groups().items()):
            low = self.cheapest(rows); high = max(rows, key=lambda r:float(r['price']))
            lines.append(f"{name}: {self.money(low['price'])} at {low['store']} (range {self.money(low['price'])} - {self.money(high['price'])})")
        with open(path, 'w', encoding='utf-8') as f: f.write('\n'.join(lines))
        messagebox.showinfo('Export complete','Summary saved successfully.')

if __name__ == '__main__':
    app = PricePilot()
    app.mainloop()

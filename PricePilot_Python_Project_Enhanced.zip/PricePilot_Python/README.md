# PricePilot — Smart Product Price Comparator

A colourful desktop shopping assistant built with **Python + CustomTkinter**. This version does not use HTML or CSS.

## New and existing features
- Colourful dashboard with product, record, store and price-gap statistics.
- **Compare Prices:** select a product and compare all saved store offers, sorted from lowest to highest.
- **Price Watch:** set a target price for a product; the app checks saved offers and marks when the target is reached.
- **Price Records:** add, search, filter by category, delete, import CSV and export CSV.
- **Insights:** average price by category and biggest recorded price difference.
- Smart-shopping tip and best-deal highlights on the dashboard.
- Downloadable text summary report.
- Automatic local saving using JSON files.
- Includes 36 sample price records for the first launch.

## Run the project (Windows)
1. Install Python 3.10 or later from https://www.python.org/downloads/ and tick **Add Python to PATH**.
2. Extract the ZIP file.
3. Open the extracted `PricePilot_Python` folder in VS Code.
4. Open **Terminal → New Terminal**.
5. Install the package:
   ```bash
   python -m pip install -r requirements.txt
   ```
6. Start the app:
   ```bash
   python pricepilot.py
   ```
   If `python` is not recognised, try `py pricepilot.py`.

## Data files
- `pricepilot_data.json` stores price records and is created automatically.
- `pricepilot_watchlist.json` stores target-price watches and is created automatically.

## CSV format
Required columns: `name,category,store,price,date`
Optional column: `notes`

## Technology used
- Python 3
- CustomTkinter for the desktop user interface
- Tkinter Treeview for the records table
- JSON for local data storage
- CSV for import and export

**No HTML or CSS is used.**
